package org.polibot.bot;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.File;
import java.io.IOException;

public class PDF {

    public PDF() {

    }

    public void crearPDF(String informe, String cafeteria) {

        try {

            PDDocument documento = new PDDocument();

            PDPage pagina = new PDPage();
            documento.addPage(pagina);

            PDPageContentStream contenido = new PDPageContentStream(documento, pagina);

            contenido.setFont(PDType1Font.HELVETICA_BOLD, 15);
            contenido.beginText();
            contenido.newLineAtOffset(100, 700);
            contenido.showText("NUEVO PEDIDO SOLICITADO!");
            contenido.newLineAtOffset(0, -20);
            contenido.setFont(PDType1Font.HELVETICA_OBLIQUE, 12);
            contenido.showText("informe Cafeteria" + cafeteria);
            contenido.endText();

            contenido.moveTo(100, 670);
            contenido.lineTo(315, 670);
            contenido.stroke();

            String[] lineas = informe.split("\n");

            contenido.beginText();
            contenido.setFont(PDType1Font.HELVETICA, 12);
            contenido.newLineAtOffset(100, 650);
            for (String linea : lineas) {
                contenido.newLineAtOffset(0, -15); // Espacio entre líneas
                contenido.showText(linea);
            }
            contenido.endText();

            contenido.close();
            documento.save(new File("pedido.pdf"));
            documento.close();

            System.out.println("PDF creado correctamente.");
        } catch (IOException e) {
            System.err.println("Error al crear el PDF: " + e.getMessage());
        }

    }

}

