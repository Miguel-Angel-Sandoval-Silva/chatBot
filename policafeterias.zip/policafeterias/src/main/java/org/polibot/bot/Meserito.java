package org.polibot.bot;

import org.polibot.Pedido;
import org.polibot.Producto;
import org.polibot.sql.Consultas;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendDocument;
import org.telegram.telegrambots.meta.api.objects.InputFile;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Meserito extends TelegramLongPollingBot {

    private String infoPedido;
    private Producto comidaSubtipo;

    private List<Producto> pproductos = new ArrayList<>();
    private List<Producto> carrito = new ArrayList<>();

    private boolean entrao = false;
    private boolean estaEnMenu = false;
    private boolean comprando = false;
    private boolean comprado = false;
    private boolean haySubtipo = false;
    private boolean pedidoGenerado = false;

    private int tiempo;

    private String cafeteria;
    private long adminID = 1268063607L;

    private Consultas consultar = new Consultas();

    private void responder(long chatId, String text) {
        EnviarRes responder = new EnviarRes(chatId, text);
        try {
            execute(responder.getMessage());
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }

    public String getBotToken() {
        return "7129730060:AAGPnXIjRv4jhdh2NGe24hnOi9bFrjFCTKk";
    }
    @Override
    public String getBotUsername() {
        return "polimeseritoBot";
    }

    @Override
    public void onUpdateReceived(Update update) {

        if (update.hasMessage() && update.getMessage().hasText()) {

            Long chatId = update.getMessage().getChatId();
            String message = update.getMessage().getText();
            System.out.println("Mensaje recibido bro: " + message);
            Long userId = update.getMessage().getFrom().getId();

            if (esAdmin(userId)) {
                if (pedidoGenerado) {
                    responder(chatId, "esooo!, hay mas pedidos por llegar");
                } else {
                    responder(chatId, "puede recibir un pedido en cualquier momento!");
                }
            } else {
                if (comprando){
                    System.out.println("estoy en comprando");
                    opcionesCarrito(message, chatId);
                } else if (comprado){
                    System.out.println("estoy en comprado");
                    pedidoRealizado(message, chatId);
                } else if (haySubtipo){
                    System.out.println("estoy en subtipo");
                    procesarSubtipo(message, chatId);
                } else {
                    System.out.println("estoy en pedir comida");
                    comandosIniciales(message, chatId);
                }
            }

        }

    }

    //ADMIN
    private boolean esAdmin(Long userId) {
        if (userId == adminID) {
            return true;
        } else { return false; }
    }
    private void recibirPedido() {
        File pdf = new File("pedido.pdf");
        mensajePDF(adminID, pdf);
        pedidoGenerado = true;
    }


    //PDFs
    private void crearPDF(Pedido pedido) {
        infoPedido = obtenerInfo(pedido);
        PDF pdf = new PDF();
        pdf.crearPDF(infoPedido, cafeteria);
    }
    private void mensajePDF(Long chatId, File file) {
        InputFile inputFile = new InputFile(file);
        SendDocument sendDocument = new SendDocument();
        sendDocument.setChatId(chatId.toString());
        sendDocument.setDocument(inputFile);
        sendDocument.setCaption("YAY, ha recibido un nuevo pedido.");
        try {
            execute(sendDocument);
        } catch (TelegramApiException e) {
            e.printStackTrace();
        }
    }
    private String obtenerInfo(Pedido pedido) {
        return consultar.infoDoc(pedido, "pedidos_" + cafeteria);
    }


    //COMANDOS
    private void mensajeIncial(Long chatId) {
        responder(chatId, "hola, bienvenido\nen que cafeteria desea comprar?\n/jaguares\n/upv");
        entrao = true;
    }
    private void comandosIniciales(String msj, Long chatId) {

        if (msj.startsWith("/start")) {
            entrao = false; estaEnMenu = false; comprando = false;
            mensajeIncial(chatId);
        } else if (msj.startsWith("/jaguares") && !estaEnMenu){
            estaEnMenu = true;
            cafeteria = "jaguares";
            menuCafeteria(chatId , cafeteria);
        } else if (msj.startsWith("/upv") && !estaEnMenu) {
            estaEnMenu = true;
            cafeteria = "upv";
            menuCafeteria(chatId , cafeteria);
        } else {
            escogerCategoria(chatId, msj);
        }

    }
    private void menuCafeteria(Long chatId, String cafe) {
        if (cafe.equalsIgnoreCase("jaguares")) {
            responder(chatId, "escoja una categoria:\n/galletas\n/dulces\n/comida\n/frituras\n/bebidas\n/postres");
        } else {
            responder(chatId, "escoja una categoria:\n/galletas\n/dulces\n/comida\n/frituras\n/bebidas");
        }
    }
    private void escogerCategoria(Long chatId, String msj) {
        if (msj.startsWith("/postres")) {
            mostrarMensajeAdecuado(chatId, estaEnMenu, "postres");
        } else if (msj.startsWith("/galletas")) {
            mostrarMensajeAdecuado(chatId, estaEnMenu, "galletas");
        } else if (msj.startsWith("/frituras")) {
            mostrarMensajeAdecuado(chatId, estaEnMenu, "frituras");
        } else if (msj.startsWith("/comida")) {
            mostrarMensajeAdecuado(chatId, estaEnMenu, "comida");
        } else if (msj.startsWith("/bebidas")) {
            mostrarMensajeAdecuado(chatId, estaEnMenu, "bebidas");
        } else if (msj.startsWith("/dulces")) {
            mostrarMensajeAdecuado(chatId, estaEnMenu, "dulces");
        } else if (msj.startsWith("/cancelarCompra")) {
            entrao = false; estaEnMenu = false; comprando = false;
            mensajeIncial(chatId);
        } else if (msj.startsWith("/cambiarCategoria")) {
            entrao = false; estaEnMenu = false; comprando = false;
            mensajeIncial(chatId);
        } else {
            respuestaInvalida(chatId);
        }

    }
    private void menuCategoria(Long chatId, String categoria) {

        comprando = true;
        pproductos.clear();
        pproductos = consultar.productos(cafeteria);
        String[] menu = consultar.mostrarMenu(categoria);

        StringBuilder response = new StringBuilder(categoria + ":\n\n");
        for (String item : menu) {
            response.append(item).append("\n");
        }

        response.append("\n/cambiarCategoria\n\n" +
                "si se equivoca siempre puede pulsar /cancelarCompra\npulse /finalizarCompra cuando lo desee");

        responder(chatId, response.toString());

    }


    //PROCESAR PEDIDO
    private void confirmarPedido(Long chatId) {

        float total = 0;
        StringBuilder response = new StringBuilder();

        response.append("confirmar pedido:\n\n");

        for (Producto item : carrito) {
            response.append(item.getNombre() + " - $" + item.getPrecio() + "\n");
            total += item.getPrecio();
            tiempo += item.getPrepTime();
        }

        response.append("\ntotal a pagar: $" + total + "\n\n/cancelarCompra\n" + "/confirmarCompra");

        responder(chatId, response.toString());

    }
    private void pedidoRealizado(String msj, Long chatId) {

        if (removerProductos(chatId)) {

            Pedido pedido = consultar.enviarPedido(carrito, "pedidos_" + cafeteria, msj, tiempo);
            String yaquedo = "ya quedo " + msj + " :)\ntu numero de orden es: " + pedido.getNum_pedido() +
                    "\npuedes pasar a recogerla en " + tiempo + " mins";
            responder(chatId, yaquedo);
            pedidoGenerado = true;
            crearPDF(pedido);
            recibirPedido();
            resetearVar();

        } else {

            String yaquedo = "puedes generar un nuevo pedido con /start";
            responder(chatId, yaquedo);
            resetearVar();

        }

    }
    private boolean removerProductos(Long chatId) {

        for (Producto p : carrito) {
            if (consultar.getStock(p, cafeteria) <= 0) {
                responder(chatId, "lo sentimos, no tenemos suficiente\n" + p.getNombre()
                        + "\n\nen existencia: " + p.getEnStock());
                consultar.devolverProducto(p, cafeteria);
                carrito.remove(p);
                return false;
            } else {
                consultar.updateStock(p, cafeteria);
            }
        }

        return true;

    }


    //OPCIONES CARRITO DE COMPRAS
    private void agregarAlCarrito(String id, Long chatId) {

        Producto item = consultar.tomarProducto(id);
        comidaSubtipo = item;

        if (comidaSubtipo.getCategoria().startsWith("comida")) {
            if (!ifsComida(comidaSubtipo, chatId)) {
                haySubtipo = false;
                carrito.add(consultar.tomarProducto(id));
            } else {
                haySubtipo = true;
            }
        } else {
            if (consultar.getStock(item, cafeteria) < 0) {
                responder(chatId, "lo sentimos, nos quedamos sin " + item.getNombre()
                        + "\nescoge otro producto por favor");
                carrito.remove(item);
            } else {
                haySubtipo = false;
                carrito.add(item);
            }
        }
    }
    private void opcionesCarrito(String msj, Long chatId) {

        if (msj.startsWith("/cancelarCompra")) {
            carrito.clear();
            comprando = false;
        } else if (msj.startsWith("/finalizarCompra")) {
            mostrarCompras();
            confirmarPedido(chatId);
        } else if (msj.startsWith("/confirmarCompra")) {
            comprando = false;
            estaEnMenu = false;
            comprado = true;
            responder(chatId, "a nombre de quien se hara el pedido?");
        } else if (msj.startsWith("/cambiarCategoria")) {
            comprando = false;
            menuCafeteria(chatId, cafeteria);
        }   else {
            String id = msj.replace("/", "");
            agregarAlCarrito(id, chatId);
        }

    }
    private void mostrarCompras() {
        for (Producto p : carrito) {
            System.out.println(p.getNombre() + " " + p.getPrecio());
        }
    }


    //HELPING METHODS
    private void mostrarMensajeAdecuado(Long chatId, boolean estaEnMenu, String cat) {
        if (estaEnMenu) {
            menuCategoria(chatId, cat);
        } else {
            responder(chatId, "Debes seleccionar primero la cafetería.");
        }
    }
    private void respuestaInvalida(Long chatId) {
        if (entrao) {
            if(estaEnMenu) {
                if (comprando) {
                    responder(chatId, "estas en proceso de compra\npuedes /cancelarCompra si quieres");
                } else {
                    responder(chatId, "ya selecciono una cafeteria para comprar\n" +
                            "si lo desea puede pulsar el comando\n/cancelarCompra para volver atras");
                }
            } else if (comprado) {
                responder(chatId, "ya has realizado una compra\nsi deseas hacer otra, puedes empezar de nuevo con /start.");
            } else {
                responder(chatId, "esa no es una opcion valida");
            }
        }
    }
    private boolean ifsComida(Producto p, Long chatId) {
        comprando = false;
        boolean flag = true;
        if (p.getNombre().startsWith("Boneless")) {
            responder(chatId, "escoja una salsa: /bbq /habanero /buffalo /sinSalsa");
        } else if (p.getNombre().startsWith("Flauta")) {
            responder(chatId, "escoja una salsa: /picadillo /salsaVerde /deshebrada /huevoConPapas");
        }  else if (p.getNombre().startsWith("Gordita") || p.getNombre().startsWith("Sope")) {
            responder(chatId, "escoja una salsa: /picadillo /salsaVerde /deshebrada /huevoConPapas");
        }   else if (p.getNombre().startsWith("Torta")) {
            responder(chatId, "escoja una salsa: /jamon /salsaVerde /deshebrada");
        }   else if (p.getNombre().startsWith("Sushi")) {
            responder(chatId, "escoja una salsa: /salmon /californiaRoll /res");
        } else {
            comprando = true;
            flag = false;
        }

        return flag;

    }
    private void procesarSubtipo(String message, Long chatId) {
        String subtipo = message.replace("/", "");
        comidaSubtipo.setNombre(comidaSubtipo.getNombre() + " [" + subtipo + "]");
        carrito.add(consultar.tomarProducto(comidaSubtipo.getId()));
        haySubtipo = false;
        comprando = true;
        responder(chatId, "ok!, puede seguir comprando mas alimentos");
    }
    private void resetearVar() {
        comprado = false;
        estaEnMenu = false;
        carrito.clear();
        tiempo = 0;
    }

}
