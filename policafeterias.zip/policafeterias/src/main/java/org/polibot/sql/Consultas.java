package org.polibot.sql;

import org.polibot.Pedido;
import org.polibot.Producto;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Consultas {

    private List<Producto> productillos = new ArrayList<>();

    public Consultas() {

    }

    public List<Producto> productos(String tabla) {

        try (var connection =  MySQLConnection.connect()){

            String selectQuery = "SELECT * FROM " + tabla;

            try (PreparedStatement statement = connection.prepareStatement(selectQuery)) {

                try (ResultSet resultSet = statement.executeQuery()) {

                    while (resultSet.next()) {

                        String id = resultSet.getString("id");
                        String nom = resultSet.getString("nombre");
                        float precio = resultSet.getFloat("precio");
                        int stock = resultSet.getInt("en_stock");
                        int prep = resultSet.getInt("t_preparacion");
                        String categoria = resultSet.getString("categoria");

                        Producto p = new Producto(id, nom, precio, stock, prep,categoria);
                        productillos.add(p);

                    }
                }
            }

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return productillos;

    }

    public String infoDoc(Pedido pedido, String tabla) {

        StringBuilder informe = new StringBuilder();
        StringBuilder orden = new StringBuilder();

        try (var connection =  MySQLConnection.connect()){

            String selectQuery = "SELECT * FROM " + tabla + " WHERE num_pedido = ?";

            try (PreparedStatement statement = connection.prepareStatement(selectQuery)) {

                statement.setInt(1, pedido.getNum_pedido());

                try (ResultSet resultSet = statement.executeQuery()) {

                    System.out.println("selecciono el pedido de: " + pedido.getNombre_user());
                    while (resultSet.next()) {

                        String id = resultSet.getString("num_pedido");
                        String user = resultSet.getString("nom_cliente");
                        orden.append(resultSet.getString("pedido"));
                        float total = resultSet.getFloat("total_pago");
                        int tiempo = resultSet.getInt("tiempo_estimado");

                        informe.append("Buenas!, tiene una orden pendiente a nombre de " + user + "\nNo. de orden: " + id + "\n\n" +
                                "Tiempo estimado dado al cliente: " + tiempo + " mins\n\n");
                        informe.append(orden);
                        informe.append("\nprecio total: $" + total);

                    }
                }
            }

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return informe.toString();

    }

    public int getStock (Producto producto, String tabla) {

        int stock = 0;

        try (var connection =  MySQLConnection.connect()){

            String selectQuery = "SELECT * FROM " + tabla + " WHERE id = ?";

            try (PreparedStatement statement = connection.prepareStatement(selectQuery)) {

                statement.setString(1, producto.getId());

                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        stock = resultSet.getInt("en_stock");
                        return stock;

                    }
                }
            }

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

        return stock;

    }

    public void updateStock (Producto producto, String tabla) {

        try (var connection =  MySQLConnection.connect()){

            String actualizarQuery = "UPDATE " + tabla + " SET en_stock = en_stock-1 \n" +
                    "WHERE id = ?;";

            try (PreparedStatement statement = connection.prepareStatement(actualizarQuery)) {
                statement.setString(1, producto.getId());

                int productoAct = statement.executeUpdate();
                if (productoAct > 0) {
                    System.out.println("El stock del producto ha sido actualizado correctamente.");
                } else {
                    System.out.println("No se encontró ningún producto con el ID proporcionado.");
                }

            }

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

    }

    public Pedido enviarPedido (List<Producto> carrito, String tabla, String nom_cliente, int tiempo){

        StringBuilder pedido = new StringBuilder();
        for (Producto item : carrito) {
            pedido.append("- " + item.getNombre() + "\n");
        }

        float total = 0;
        for (Producto item : carrito) {
            total += item.getPrecio();
        }

        try (var connection =  MySQLConnection.connect()){

            String insertarQuery = "INSERT INTO " + tabla + " (nom_cliente, pedido, total_pago, tiempo_estimado) " +
                                   "VALUES (?, ?, ?, ?)";

            try (PreparedStatement insertStatement = connection.prepareStatement(insertarQuery, Statement.RETURN_GENERATED_KEYS)) {
                insertStatement.setString(1, nom_cliente);
                insertStatement.setString(2, pedido.toString());
                insertStatement.setFloat(3, total);
                insertStatement.setInt(4, tiempo);

                int filasInsertadas = insertStatement.executeUpdate();

                if (filasInsertadas > 0) {
                    ResultSet generatedKeys = insertStatement.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        int idPedido = generatedKeys.getInt(1);
                        System.out.println("Pedido enviado correctamente a la tabla " + tabla + " con el ID: " + idPedido);
                        Pedido nwPedido = new Pedido(idPedido, nom_cliente, pedido, total, tiempo);
                        return nwPedido;
                    }
                }

                System.out.println("No se pudo enviar el pedido a la tabla " + tabla);
                return null;
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
            return null;
        }

    }

    public void devolverProducto(Producto producto, String tabla) {

        try (var connection =  MySQLConnection.connect()){

            String actualizarQuery = "UPDATE " + tabla + " SET en_stock = en_stock+? \n" +
                    "WHERE id = ?;";

            try (PreparedStatement statement = connection.prepareStatement(actualizarQuery)) {
                statement.setInt(1, producto.getEnStock());
                statement.setString(2, producto.getId());

                int productoAct = statement.executeUpdate();
                if (productoAct > 0) {
                    System.out.println("El stock del producto ha sido actualizado correctamente.");
                } else {
                    System.out.println("No se encontró ningún producto con el ID proporcionado.");
                }

            }

        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }

    }


    public String[] mostrarMenu(String categoria) {

        int contador = 0;
        for (Producto p : productillos) {
            if (p.getCategoria().equalsIgnoreCase(categoria)) {
                contador++;
            }
        }

        String[] lista = new String[contador];

        int i = 0;
        for (Producto p : productillos) {
            if (p.getCategoria().equalsIgnoreCase(categoria)) {
                lista[i] = "| /" + p.getId() + ". " + p.getNombre() + " - $" + p.getPrecio();
                i++;
            }
        }

        return lista;

    }

    public Producto tomarProducto(String id) {

        for (Producto p : productillos) {
            if (p.getId().equalsIgnoreCase(id)) {

                return p;
            }
        }

        return null;
    }

}
