package org.polibot;

public class Producto {

    private String id;
    private String nombre;
    private float precio;
    private int enStock;
    private int prepTime;
    private String categoria;


    public Producto (String id, String nombre, float precio, int enStock, int prepTime, String categoria) {

        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.enStock = enStock;
        this.prepTime = prepTime;
        this.categoria = categoria;

    }

    public Producto() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getEnStock() {
        return enStock;
    }

    public void setEnStock(int enStock) {
        this.enStock = enStock;
    }

    public int getPrepTime() {
        return prepTime;
    }

    public void setPrepTime(int prepTime) {
        this.prepTime = prepTime;
    }

    public String getCategoria() {
        return categoria;
    }
}
