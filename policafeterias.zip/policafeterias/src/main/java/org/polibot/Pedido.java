package org.polibot;

public class Pedido {

    private int num_pedido;
    private String nombre_user;
    private StringBuilder orden;
    private float total;
    private int tiempo_estimado;

    public Pedido(int numPedido, String nombreUser, StringBuilder orden, float total, int tiempoEstimado) {
        num_pedido = numPedido;
        nombre_user = nombreUser;
        this.orden = orden;
        this.total = total;
        tiempo_estimado = tiempoEstimado;
    }

    public int getNum_pedido() {
        return num_pedido;
    }

    public void setNum_pedido(int num_pedido) {
        this.num_pedido = num_pedido;
    }

    public String getNombre_user() {
        return nombre_user;
    }

    public void setNombre_user(String nombre_user) {
        this.nombre_user = nombre_user;
    }

    public StringBuilder getOrden() {
        return orden;
    }

    public void setOrden(StringBuilder orden) {
        this.orden = orden;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public int getTiempo_estimado() {
        return tiempo_estimado;
    }

    public void setTiempo_estimado(int tiempo_estimado) {
        this.tiempo_estimado = tiempo_estimado;
    }
}
